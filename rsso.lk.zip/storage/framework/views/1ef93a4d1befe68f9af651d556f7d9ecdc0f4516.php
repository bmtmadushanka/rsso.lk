<div class="footer">
            <div class="footer-top">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-3 col-md-6 footer-links">
                            <h4>About Us</h4>
                            <ul>
                                <li><i class="ion-ios-arrow-forward"></i> <a href="<?php echo e(route('index')); ?>">Home</a></li>
                                <li><i class="ion-ios-arrow-forward"></i> <a href="<?php echo e(route('about')); ?>">About us</a></li>
                                <li><i class="ion-ios-arrow-forward"></i> <a href="<?php echo e(route('services')); ?>">Our services</a></li>
                                <li><i class="ion-ios-arrow-forward"></i> <a href="#">Terms & condition</a></li>
                                <li><i class="ion-ios-arrow-forward"></i> <a href="#">Privacy policy</a></li>
                            </ul>
                        </div>

                        <div class="col-lg-3 col-md-6 footer-links">
                            <h4>Useful Links</h4>
                            <ul>
                                <li><i class="ion-ios-arrow-forward"></i> <a href="#">Lorem ipsum</a></li>
                                <li><i class="ion-ios-arrow-forward"></i> <a href="#">Pellentesque</a></li>
                                <li><i class="ion-ios-arrow-forward"></i> <a href="#">Suspendisse egestas</a></li>
                                <li><i class="ion-ios-arrow-forward"></i> <a href="#">Nulla tristique</a></li>
                                <li><i class="ion-ios-arrow-forward"></i> <a href="#">Phasellus leo</a></li>
                            </ul>
                        </div>

                        <div class="col-lg-3 col-md-6 footer-contact">
                            <h4>Contact Us</h4>
                            <p>
                                No.120<br>
                                Thalawa, Haltota<br>
                                Bandaragama <br>
                                <strong>Phone:</strong> 0342252696<br>
                                <strong>Email:</strong> info@example.com<br>
                            </p>

                            <div class="social-links">
                                <a href="#"><i class="ion-logo-twitter"></i></a>
                                <a href="#"><i class="ion-logo-facebook"></i></a>
                                <a href="#"><i class="ion-logo-linkedin"></i></a>
                                <a href="#"><i class="ion-logo-instagram"></i></a>
                                <a href="#"><i class="ion-logo-googleplus"></i></a>
                            </div>

                        </div>

                        <div class="col-lg-3 col-md-6 footer-newsletter">
                            <h4>Join With Us</h4>
                            <p>Every one can part of our lovly family.click apply now to join</p>
                            <form action="" method="post">
                                <input type="email" name="email"><input type="submit"  value="Subscribe">
                            </form>
                        </div>

                    </div>
                </div>
            </div>

            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-6 copyright">
                        Copyright &copy; 2020 <a href="https://codecyon.com">Codecyon</a>. All Rights Reserved
                    </div>
                    <div class="col-md-6 credit">
                        Template by <a href="https://codecyon.com">Codecyon</a>
                    </div>
                </div>
            </div>
        </div><?php /**PATH D:\Projects\rsso.lk\resources\views/footer.blade.php ENDPATH**/ ?>