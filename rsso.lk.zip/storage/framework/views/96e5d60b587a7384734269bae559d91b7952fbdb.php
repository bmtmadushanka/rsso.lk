<img src="img/logo.png" alt="Logo" style="width: 80px">
<?php /**PATH D:\Projects\rsso.lk\resources\views/vendor/jetstream/components/application-logo.blade.php ENDPATH**/ ?>