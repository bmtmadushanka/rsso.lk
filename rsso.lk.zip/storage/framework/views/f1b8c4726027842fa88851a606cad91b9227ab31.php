<a href="/">
<img src="img/logo.png" alt="Logo" style="width: 80px">
</a>
<?php /**PATH D:\Projects\rsso.lk\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>